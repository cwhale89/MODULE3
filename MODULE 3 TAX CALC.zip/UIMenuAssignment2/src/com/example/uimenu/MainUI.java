package com.example.uimenu;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class MainUI extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JTextArea textArea;
    private JPanel contentPanel;

    public MainUI() {
        setTitle("UI Menu");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Center the window

        // Main content panel
        contentPanel = new JPanel(new BorderLayout());

        // Menu bar setup
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenu editMenu = new JMenu("Edit");
        JMenu helpMenu = new JMenu("Help");

        // File Menu items
        JMenuItem saveItem = new JMenuItem("Save");
        JMenuItem exitItem = new JMenuItem("Exit");
        fileMenu.add(saveItem);
        fileMenu.add(exitItem);

        // Edit Menu items
        JMenuItem colorItem = new JMenuItem("Change Background Color");
        editMenu.add(colorItem);

        // Help Menu items
        JMenuItem aboutItem = new JMenuItem("About");
        helpMenu.add(aboutItem);

        menuBar.add(fileMenu);
        menuBar.add(editMenu);
        menuBar.add(helpMenu);
        setJMenuBar(menuBar);

        // Text area setup
        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);
        contentPanel.add(scrollPane, BorderLayout.CENTER);

        // Status bar setup
        JLabel statusBar = new JLabel(" Ready");
        statusBar.setBorder(BorderFactory.createEtchedBorder());
        contentPanel.add(statusBar, BorderLayout.SOUTH);

        // Action Listeners
        saveItem.addActionListener(e -> saveToFile(textArea.getText()));
        exitItem.addActionListener(e -> System.exit(0));
        colorItem.addActionListener(e -> contentPanel.setBackground(getRandomOrangeColor()));
        aboutItem.addActionListener(e -> showAboutDialog());

        add(contentPanel);
        setVisible(true);
    }

    private Color getRandomOrangeColor() {
        Random random = new Random();
        int red = 255;
        int green = random.nextInt(166); // Values from 0 to 165
        int blue = random.nextInt(51);   // Values from 0 to 50
        return new Color(red, green, blue);
    }

    // Helper method to save content to a file
    private void saveToFile(String content) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String filename = "saved_text_" + timestamp + ".txt";
        try (FileWriter writer = new FileWriter(filename)) {
            writer.write(content);
            JOptionPane.showMessageDialog(this, "Content saved to " + filename, "Save Successful", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving file: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Helper method for the About dialog
    private void showAboutDialog() {
        JOptionPane.showMessageDialog(this, "Simple UI Menu Example\nCreated by Your Name", "About", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MainUI::new);
    }
}